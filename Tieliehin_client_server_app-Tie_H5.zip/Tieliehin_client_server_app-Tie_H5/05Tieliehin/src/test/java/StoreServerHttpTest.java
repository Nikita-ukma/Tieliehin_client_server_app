import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import models.Message;
import models.Packet;
import models.Processor;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import java.io.IOException;
import java.sql.SQLException;

public class StoreServerHttpTest {

    private static String authToken;

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 8080;

        // Get the auth token
        authToken = given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("login", "admin")
                .formParam("password", "21232f297a57a5a743894a0e4a801fc3")
                .when()
                .post("/login")
                .then()
                .statusCode(200)
                .extract()
                .path("token");
    }

    @Test
    public void testLogin() {
        given()
                .contentType("application/x-www-form-urlencoded")
                .formParam("login", "admin")
                .formParam("password", "21232f297a57a5a743894a0e4a801fc3")
                .when()
                .post("/login")
                .then()
                .statusCode(200)
                .body("token", notNullValue());
    }

    @Test
    public void testCreateGood() {
        String goodData = "Milk,Milk Description,Manufacturer A,100,1.99,1";

        given()
                .header("Authorization", "Bearer " + authToken)
                .contentType("application/json")
                .body(goodData)
                .when()
                .put("/api/good")
                .then()
                .statusCode(201);
    }

    @Test
    public void testGetGood() throws SQLException, IOException {
        String goodData = "Milk,Milk Description,Manufacturer A,100,1.99,1";

        // First, create a good
        Response response = given()
                .header("Authorization", "Bearer " + authToken)
                .contentType("application/json")
                .body(goodData)
                .when()
                .put("/api/good");


        // Now, get the good
        given()
                .header("Authorization", "Bearer " + authToken)
                .when()
                .get("/api/good/" + 2)
                .then()
                .statusCode(200)
                .body("name", equalTo("Milk"))
                .body("description", equalTo("Milk Description"))
                .body("manufacturer", equalTo("Manufacturer A"))
                .body("quantity", equalTo(100))
                .body("price", equalTo(1.99f))
                .body("group_id", equalTo(1));
    }

    @Test
    public void testUpdateGood() {
        String goodData = "Milk,Milk Description,Manufacturer A,100,1.99,1";

        // First, create a good
        Response response = given()
                .header("Authorization", "Bearer " + authToken)
                .contentType("application/json")
                .body(goodData)
                .when()
                .put("/api/good");

        // Update the good
        String updatedGoodData = "Updated Milk,Updated Milk Description,Manufacturer B,200,2.99,2";
        given()
                .header("Authorization", "Bearer " + authToken)
                .contentType("application/json")
                .body(updatedGoodData)
                .when()
                .post("/api/good/" + 1)
                .then()
                .statusCode(204);
    }

    @Test
    public void testDeleteGood() {
        String goodData = "Milk,Milk Description,Manufacturer A,100,1.99,1";

        // First, create a good
        Response response = given()
                .header("Authorization", "Bearer " + authToken)
                .contentType("application/json")
                .body(goodData)
                .when()
                .put("/api/good");

        // Delete the good
        given()
                .header("Authorization", "Bearer " + authToken)
                .when()
                .delete("/api/good/" + 1)
                .then()
                .statusCode(204);
    }
}