package server;

import com.google.gson.JsonObject;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import commands.CreateProductCommand;
import commands.ReadProductCommand;
import commands.UpdateProductCommand;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import models.Processor;
import models.Packet;
import models.Message;

public class StoreServerHttp {
    private static final Key SECRET_KEY = Keys.secretKeyFor(SignatureAlgorithm.HS256); // Secret key for JWT signing and validation
    private static final Processor processor = new Processor(); // Create processor instance

    public static void main(String[] args) throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        server.createContext("/login", new LoginHandler());
        server.createContext("/api/good", new CreateGoodHandler(processor));
        server.createContext("/api/good/", new GoodHandler());
        server.setExecutor(null); // creates a default executor
        server.start();
        System.out.println("Server started on port 8080");
    }

    static class LoginHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("POST".equals(exchange.getRequestMethod())) {
                String query = new String(exchange.getRequestBody().readAllBytes());
                Map<String, String> params = queryToMap(query);

                String login = params.get("login");
                String password = params.get("password");

                if ("admin".equals(login) && "21232f297a57a5a743894a0e4a801fc3".equals(password)) {
                    String token = generateToken(login);
                    String response = "{\"token\":\"" + token + "\"}";
                    exchange.getResponseHeaders().set("Content-Type", "application/json");
                    exchange.sendResponseHeaders(200, response.length());
                    OutputStream os = exchange.getResponseBody();
                    os.write(response.getBytes());
                    os.close();
                } else {
                    exchange.sendResponseHeaders(401, -1);
                }
            } else {
                exchange.sendResponseHeaders(405, -1); // Method Not Allowed
            }
        }

        private String generateToken(String login) {
            long nowMillis = System.currentTimeMillis();
            Date now = new Date(nowMillis);

            return Jwts.builder()
                    .setSubject(login)
                    .setIssuedAt(now)
                    .setExpiration(new Date(nowMillis + 3600000)) // 1 hour expiration
                    .signWith(SECRET_KEY)
                    .compact();
        }

        private Map<String, String> queryToMap(String query) {
            Map<String, String> result = new HashMap<>();
            for (String param : query.split("&")) {
                String[] entry = param.split("=");
                if (entry.length > 1) {
                    result.put(entry[0], entry[1]);
                } else {
                    result.put(entry[0], "");
                }
            }
            return result;
        }
    }

    static class CreateGoodHandler implements HttpHandler {
        private final Processor processor;

        public CreateGoodHandler(Processor processor) {
            this.processor = processor;
        }

        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!validateToken(exchange)) {
                exchange.sendResponseHeaders(403, -1); // Forbidden
                return;
            }

            if ("PUT".equals(exchange.getRequestMethod())) {
                String requestBody = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
                Packet packet = new Packet(new Message(1, 0, requestBody)); // Command 1: Create Product
                try {
                    String[] args = packet.getbMsg().getMessage().split(",");
                    CreateProductCommand createCommand = new CreateProductCommand();
                    createCommand.execute(args);
                    exchange.sendResponseHeaders(201, -1); // Created
                } catch (Exception e) {
                    System.out.println(e);
                    exchange.sendResponseHeaders(409, -1); // Conflict
                }
            } else {
                exchange.sendResponseHeaders(405, -1); // Method Not Allowed
            }
        }
    }

    static class GoodHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!validateToken(exchange)) {
                exchange.sendResponseHeaders(403, -1); // Forbidden
                return;
            }

            String method = exchange.getRequestMethod();
            String path = exchange.getRequestURI().getPath();
            String idStr = path.substring(path.lastIndexOf('/') + 1);
            int id;

            try {
                id = Integer.parseInt(idStr);
            } catch (NumberFormatException e) {
                exchange.sendResponseHeaders(404, -1); // Not Found
                return;
            }

            switch (method) {
                case "GET":
                    handleGet(exchange, id);
                    break;
                case "POST":
                    handlePost(exchange, id);
                    break;
                case "DELETE":
                    handleDelete(exchange, id);
                    break;
                default:
                    exchange.sendResponseHeaders(405, -1); // Method Not Allowed
                    break;
            }
        }
            private void handleGet(HttpExchange exchange, int id) throws IOException {
                Packet packet = new Packet(new Message(2, 0, String.valueOf(id))); // Command 2: Read Product
                try {
                    String[] args = packet.getbMsg().getMessage().split(",");
                    ReadProductCommand readCommand = new ReadProductCommand();
                    readCommand.execute(args);
                    JsonObject productJson = readCommand.getProductJson();
                    if (productJson != null) {
                        String response = productJson.toString();
                        exchange.getResponseHeaders().set("Content-Type", "application/json");
                        exchange.sendResponseHeaders(200, response.length());
                        OutputStream os = exchange.getResponseBody();
                        os.write(response.getBytes());
                        os.close();
                    } else {
                        exchange.sendResponseHeaders(404, -1); // Not Found
                    }
                } catch (Exception e) {
                    exchange.sendResponseHeaders(404, -1); // Not Found
                }
            }

        private void handlePost(HttpExchange exchange, int id) throws IOException {
            String requestBody = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
            Packet packet = new Packet(new Message(3, 0, id + "," + requestBody)); // Command 3: Update Product
            try {
                String[] args = packet.getbMsg().getMessage().split(",");
                UpdateProductCommand readCommand = new UpdateProductCommand();
                readCommand.execute(args);
                exchange.sendResponseHeaders(204, -1); // No Content
            } catch (Exception e) {
                System.out.println(e);
                exchange.sendResponseHeaders(409, -1); // Conflict or 404 Not Found
            }
        }

        private void handleDelete(HttpExchange exchange, int id) throws IOException {
            Packet packet = new Packet(new Message(4, 0, String.valueOf(id))); // Command 4: Delete Product
            try {
                processor.processPacket(packet);
                exchange.sendResponseHeaders(204, -1); // No Content
            } catch (Exception e) {
                exchange.sendResponseHeaders(404, -1); // Not Found
            }
        }
    }

    private static boolean validateToken(HttpExchange exchange) {
        String authHeader = exchange.getRequestHeaders().getFirst("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            try {
                Jwts.parserBuilder().setSigningKey(SECRET_KEY).build().parseClaimsJws(token);
                return true;
            } catch (Exception e) {
                return false;
            }
        }
        return false;
    }
}
